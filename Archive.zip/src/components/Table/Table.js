import React, {useState, useEffect} from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./Table.css";
function Table() {
    const navigate = useNavigate()
  return (
    <>
      <div className="table_wrapper">
        <div className="table_wrapper_inner">
        <a href="javascript:void(0)" className="backpage" onClick={() => navigate(-1)}>Back to previous page </a>
          <p>Clicking on the clients link, we now have our list of client, and the Edit,Remove and Add Client Features</p>
          <div className="client_list">
            <h4>Client</h4>
            <button onClick={() => navigate('/form')}>Add Row</button>
          </div>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              <tr>
                <td>Deepak</td>
                <td>deepak@gmail.com</td>
                <td>
                  <button className="edit">Edit</button>
                  <button className="delete">Delete</button>
                </td>
              </tr>
              <tr>
                <td>Deepak</td>
                <td>deepak@gmail.com</td>
                <td>
                  <button className="edit">Edit</button>
                  <button className="delete">Delete</button>
                </td>
              </tr>
              <tr>
                <td>Deepak</td>
                <td>deepak@gmail.com</td>
                <td>
                  <button className="edit">Edit</button>
                  <button className="delete">Delete</button>
                </td>
              </tr>
              <tr>
                <td>Deepak</td>
                <td>deepak@gmail.com</td>
                <td>
                  <button className="edit">Edit</button>
                  <button className="delete">Delete</button>
                </td>
              </tr>
              <tr>
                <td>Deepak</td>
                <td>deepak@gmail.com</td>
                <td>
                  <button className="edit">Edit</button>
                  <button className="delete">Delete</button>
                </td>
              </tr>
              <tr>
                <td>Deepak</td>
                <td>deepak@gmail.com</td>
                <td>
                  <button className="edit">Edit</button>
                  <button className="delete">Delete</button>
                </td>
              </tr>
              <tr>
                <td>Deepak</td>
                <td>deepak@gmail.com</td>
                <td>
                  <button className="edit">Edit</button>
                  <button className="delete">Delete</button>
                </td>
              </tr>
              <tr>
                <td>Deepak</td>
                <td>deepak@gmail.com</td>
                <td>
                  <button className="edit">Edit</button>
                  <button className="delete">Delete</button>
                </td>
              </tr>
              <tr>
                <td>Deepak</td>
                <td>deepak@gmail.com</td>
                <td>
                  <button className="edit">Edit</button>
                  <button className="delete">Delete</button>
                </td>
              </tr>
              <tr>
                <td>Deepak</td>
                <td>deepak@gmail.com</td>
                <td>
                  <button className="edit">Edit</button>
                  <button className="delete">Delete</button>
                </td>
              </tr>
              <tr>
                <td>Deepak</td>
                <td>deepak@gmail.com</td>
                <td>
                  <button className="edit">Edit</button>
                  <button className="delete">Delete</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

export default Table;
