import React from "react";
import { useNavigate } from "react-router-dom";
import './Form.css'

function Form() {
  const navigate = useNavigate();
  return (
    <div className="form">
      <div className="textLeft">
      <a
        href="javascript:void(0)"
        className="backpage"
        onClick={() => navigate(-1)}
      >
        Back to previous page
      </a>
      </div>
      <h2 className="head-title">Angular + Spring Boot CRUD Full Stack App</h2>
      <div className="form-wrapper">
      <div className="form-head">Create Employee</div>
        <form>
         
          <div className="form-group">
            <label>Name</label>
            <input type="text" />
          </div>
          <div className="form-group">
            <label>Email Id Name</label>
            <input type="text" />
          </div>
          <button>Submit</button>
        </form>
      </div>
    </div>
  );
}

export default Form;
