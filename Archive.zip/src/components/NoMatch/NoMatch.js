import React from "react";

import { useNavigate } from "react-router-dom";
function NoMatch() {
  const navigate = useNavigate();
  return (
    <div className="NoMatch">
      <a
        href="javascript:void(0)"
        className="backpage"
        onClick={() => navigate(-1)}
      >
        Back to previous page{" "}
      </a>
      No Match Found
    </div>
  );
}

export default NoMatch;
