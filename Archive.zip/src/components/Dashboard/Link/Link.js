import React from 'react'
import './Link.css'
import { useNavigate } from 'react-router-dom';

function Link() {
    const navigate = useNavigate()
  return (
  <div className='linkbox-wrapper'>
    <div className="linkbox">
         <div className='link-head'>
            <h3>Table Link</h3>
            
         </div>
         <ul className='link-list'>
                <li><a href="javascript:void(0)" onClick={() => navigate('/table')}>Link1</a></li>
                <li><a href="javascript:void(0)" onClick={() => navigate('/table')}>Link2</a></li>
                <li><a href="javascript:void(0)" onClick={() => navigate('/table')}>Link3</a></li>
                <li><a href="javascript:void(0)" onClick={() => navigate('/table')}>Link4</a></li>
            </ul>
    </div>
  </div>
  );
}

export default Link;
