import React from 'react'
import './Sidebar.css'
import logo from './../logo.jpeg'
function Sidebar() {
  return (
    <div className="sidebar">
       <a href="javascript:void(0)" className='logo-icon'><img src={logo} alt=""/></a>
    </div>
  );
}

export default Sidebar;
