import React from 'react'
import './Head.css'

function Head() {
  return (
    <div className="head">
        <h1>Admin Dashboard</h1>
    </div>
  );
}

export default Head;
