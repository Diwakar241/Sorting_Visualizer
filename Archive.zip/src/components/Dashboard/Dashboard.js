import React from 'react'
import './Dashboard.css'
import Sidebar from './Sidebar/Sidebar'
import Head from './Head/Head'
import Link from './Link/Link'
function Dashboard() {
  return (
    <div className="dashboard">
        <div className="dashboard-wrapper">
             <Sidebar/>
             <div className='right-side'>
               <Head/>
               <Link/>
             </div>
        </div>
    </div>
  );
}

export default Dashboard;
