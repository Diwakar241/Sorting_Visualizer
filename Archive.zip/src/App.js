import React from 'react'
import './App.css';
import { Route, Routes } from 'react-router-dom';
import Dashboard from './components/Dashboard/Dashboard'
import Table from './components/Table/Table'
import Form from './components/Form/Form'
import NoMatch from './components/NoMatch/NoMatch'
function App() {
  return (
    <div className="App">
      <Routes>
         <Route path="/" element={<Dashboard/>}/>
         <Route path="table" element={<Table/>}/>
         <Route path="form" element={<Form/>}/>
         <Route path="*" element={<NoMatch/>}/>
      </Routes>
    </div>
  );
}

export default App;
